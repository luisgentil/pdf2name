#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      luis.gentil.ext
#
# Created:     28/10/2022
# Copyright:   (c) luis.gentil.ext 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    print("Hello world embebido :)")

if __name__ == '__main__':
    main()
