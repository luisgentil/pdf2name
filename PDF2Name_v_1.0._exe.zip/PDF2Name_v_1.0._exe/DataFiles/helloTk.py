#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      luis.gentil.ext
#
# Created:     28/10/2022
# Copyright:   (c) luis.gentil.ext 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from tkinter import *
  
root = Tk() 
a = Label(root, text ="Hello World") 
a.pack() 
  
root.mainloop() 
